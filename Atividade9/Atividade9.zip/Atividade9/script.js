var form = document.getElementById("form");
var n1 = document.getElementById("a");
var n2 = document.getElementById("b");
var n3 = document.getElementById("c");

var valorMaior;
var ordemCrescente;

function maior(){
    if(parseInt(n1.value) > parseInt(n2.value) && parseInt(n1.value) > parseInt(n3.value)){
        valorMaior = parseInt(n1.value);
    }else if(parseInt(n2.value) > parseInt(n3.value) && parseInt(n2.value) > parseInt(n3.value)){
        valorMaior = parseInt(n2.value);
    }else{
        valorMaior = parseInt(n3.value);
    }

    alert("O maior número é: " + valorMaior);

    form.reset();
}

function crescente(){
    ordemCrescente = [n1.value, n2.value, n3.value];

    ordemCrescente.sort((a, b) => {
        return a-b;
    });

    alert("A ordem crescente se dá por: " + ordemCrescente);

    form.reset();
}