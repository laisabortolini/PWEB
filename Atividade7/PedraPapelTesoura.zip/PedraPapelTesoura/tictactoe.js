while (true){
    jogador1 =  prompt("Jogador 1, insira sua escolha: pedra, papel ou tesoura");
    jogador2 = prompt("Jogador 2, insira sua escolha: pedra, papel ou tesoura");

    if (jogador1 ==  "tesoura"){
        if(jogador2 == "tesoura"){ 
            alert("Empate");
        }
        else if(jogador2 == "pedra"){
            alert("Pedra quebra tesoura, jogador 2 venceu!");
        }
        else if(jogador2 == "papel"){
            alert("Tesoura corta papel, jogador 1 venceu!");
        }
    }
    if (jogador1 ==  "pedra"){
        if(jogador2 == "pedra"){ 
            alert("Empate");
        }
        else if(jogador2 == "papel"){
            alert("Papel embala pedra, jogador 2 venceu!");
        }
        else if(jogador2 == "tesoura"){
            alert("Pedra quebra tesoura, jogador 1 venceu!");
        }

    }

    if (jogador1 ==  "papel"){
        if(jogador2 == "papel"){ 
            alert("Empate");
        }
        else if(jogador2 == "tesoura"){
            alert("Tesoura corta papel, jogador 2 venceu!");
        }
        else if(jogador2 == "pedra"){
            alert("Papel embala pedra, jogador 1 venceu!");
        }
    }
}

